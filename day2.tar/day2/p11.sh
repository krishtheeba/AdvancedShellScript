PS3="Select you Choice:"
select var in files process fsmount memory quit
do
	case $var in 
	files) echo " List of files:-"
		ls -l
		echo "Exit from file menu"
		;;
	process)
		echo "Current Process"
		ps
		echo "Exit from process menu"
		;;
	fsmount)
		echo "Mounted filesystem:"
		df -Th
		;;
	memory) echo "Current memory report :-"
		free
		;;
	quit) echo "Thankyou" ; break
		;;
	*) echo "Sorry your input not matched"
	esac
done
