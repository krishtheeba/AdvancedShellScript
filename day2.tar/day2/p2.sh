read -p "Enter a file name: " fname

if [ -e $fname ]
then
	if [ -f $fname ];then
		echo "Input File: $fname is a Regular file"
		ls -l $fname	
	elif [ -d $fname ];then
		echo "Input file: $fname is a Directory file"
		ls -ld $fname
	else
		echo "Yes input file: $fname exist"
		file $fname 
	fi
else
	echo "Sorry input file: $fname not exist"
fi

