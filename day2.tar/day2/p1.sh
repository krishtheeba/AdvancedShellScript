read -p "Enter a file name: " fname

if [ -e $fname ]
then
	echo "Yes input File: $fname exist"
else
	echo "Sorry input file: $fname not exist"
fi

