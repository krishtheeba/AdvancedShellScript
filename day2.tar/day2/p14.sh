
read -p "Enter file name:" fname

if ! [ -f $fname ]
then
	echo "Usage:Sorry file $fname is nor reg. file"
fi


read -p "Enter the result file: " wfname

if [ -e $wfname ]
then
	echo "Usage:Sorry file $wfname exist already"
	exit
fi

while read var
do
	echo "$var"
done<$fname   >$wfname
