

c=0
while [ $c -lt 3 ]
do
	c=`expr $c + 1`

	read -p "Enter the Login name " name

	if [ "$name" == "userA" ];then
		echo "Login Matched"
	else
		echo "Try-Again"
	fi
done
