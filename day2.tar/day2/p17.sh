
while read var
do
	echo "command : $var
	Result : `$var`"
done<cmds.txt >result.log 2>&1
