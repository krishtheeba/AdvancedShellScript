


read -p "Enter a app name " app

case $app in 
flask|Flask|FLASK) port=5000;;
Django) port=6000;;
promethesus) port=7000;;
*) app="testApp"
port=8000
esac


echo "App Name :$app Running Port : $port"

