


read -p "Enter a app name " app

case $app in 
flask|Flask|FLASK) port=5000;;
Django) port=6000;;
promethesus) port=7000;;
*) app="testApp"
port=8000
esac


if [ $app == "Flask" -o $app == "FLASK" -o $app == "flask" ]
then
	port=5000
elif [ $app == "Django" ]
then
	port=6000
elif [ $app == "promethesus" ]
then
	port=7000
else
	app="testApp"
	port=8000
fi







echo "App Name :$app Running Port : $port"

