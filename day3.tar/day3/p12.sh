

app="webapp"
port=1000

fx(){
	var1=150
	total=`expr $var1 + 100`
	echo "Total=$total"
}
echo $$

