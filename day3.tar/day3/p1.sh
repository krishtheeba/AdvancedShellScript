
echo $0

fname=`basename $0`

echo "Working script filename : $fname

Script $PID : $$

Parent Process PID : $PPID"
