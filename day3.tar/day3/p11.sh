create_directory(){
	# To create a directory
	
	if [ $#  -eq 0 ]; then

		echo "Usage: Argument is Missing"
		echo "$FUNCNAME <directory>"
		exit
	fi

	[ -d $1 ] || mkdir $1
	if [ $? -eq 0 ];then
		echo "Directory $1 created"
	else
		echo "Directory $1 creation Failed"
	fi

}

#create_directory Demo

Arr=(Demo1 Demo2 Demo3 Demo4)
for var in ${Arr[@]}
do
	create_directory $var    
done
