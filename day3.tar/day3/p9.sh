
f1(){
	echo "List of servers:"
	
	echo "Server 1=$1 server2=$2"
	
	echo "Total no. of function inputs : $#"

	for var in $@
	do
		echo "$var"
	done
}


f1 unix linux mac minix qnx    # func call with arg

f1    # simple function callis f3  block


