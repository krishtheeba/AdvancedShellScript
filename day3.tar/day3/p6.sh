
aips=($@)   # array with cmdline arguments

echo "No. of elements from array : ${#aips[@]}"  # total no. of array elmts

echo "No. of elements from cmdline : $#"  # total no. of cmdline args

echo $@  # list of all cmdline args
echo ${aips[@]} # list of all array elements


aips=(fastAPI $@ Flask Rails Django)

echo " No of elements from array : ${#aips[@]}"
echo " No of elements from cmdline : $#"

echo $@
echo ${aips[@]}

