
function display(){

	uname -rs
	ps
	hostname
}
display
