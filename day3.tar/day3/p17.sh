

con_sh=(`find /etc -name "*.sh"`)

echo "Total no. of sh files : ${#con_sh[@]}"


if [ ${#con_sh[@]} -lt 10 ];then
	for var in ${con_sh[@]}
	do
		echo $var
	done
else
	echo "No. of files more than 10"
fi
