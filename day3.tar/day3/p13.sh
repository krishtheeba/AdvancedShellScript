
echo "This is $0 file"

source ./p12.sh

echo "App name: $app Port number : $port"

