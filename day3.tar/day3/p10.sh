
echo "From Commandline arg:-"
echo $1 $2 $3
echo $@
echo $#


sleep 5;
echo

f1(){
	echo "This  is $FUNCNAME block"
	echo "1st arg: $1 2nd arg: $2"
	echo "Total no. of args: $#"
	echo "List of all : $@"
	echo"Exit from $FUNCNAME block"
}

f2(){
	echo "This  is $FUNCNAME block"
	echo "1st arg: $1 2nd arg: $2"
	echo "Total no. of args: $#"
	echo "List of all : $@"
	echo"Exit from $FUNCNAME block"
}

f1 10 20 30 40 50 60 70 80  # function call with arg
sleep 2
f2 $1 $2 $3  # function call with arg

echo "Exit from $0 script"
