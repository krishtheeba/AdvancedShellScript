

optstring="a:bc"

while getopts $optstring opt
do
	case $opt in
	a) echo "Option -a was invoked" 
	;;
	b) echo "Option -b was invoked"
	;;
	c) echo "Option -c was invoked"
	;;
	*) echo "Invalid Option"
	esac
done


