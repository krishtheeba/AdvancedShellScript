
hosts=()

echo "No. of Items : ${#hosts[@]}"

c=0
while [ $c -lt 5 ]
do
	read -p "Enter a hostname : " h
	hosts[$c]=$h
	c=`expr $c + 1`
done

echo "List of Host details:-"

for var in ${hosts[@]}
do
	echo "$var"
done


echo "No. of Items : ${#hosts[@]}"
