f1(){
	echo "This is f1 block"
	ls -l
	echo "Exist from f1"
}

f2(){
	echo "This is $FUNCNAME block"
	ps -f
	echo "Total no. of Process : `ps -e|wc -l`"
	echo "Exit from $FUNCNAME"
}

f3(){
	echo "This is $FUNCNAME  block"
	df -Th
	echo "Exit from $FUNCNAME"
}

f1
sleep 2

f2
sleep 2

f3
sleep 3
