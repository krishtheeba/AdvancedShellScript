
while getopts "hd:" opt
do
	case $opt in
	d)` mkdir "$OPTARG"` ;;
	h) echo "$0 -d day3" ;;
	esac
done
