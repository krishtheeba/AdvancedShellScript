get_name(){
	local name="Sam"
	echo $name
}
myname=$(get_name)
echo "name is : $myname"
