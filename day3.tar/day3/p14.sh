
echo "This is $0 file"

. ./p12.sh

echo "App $app Details:-
----------------------
app=$app port=$port
----------------------"

fx
