
PS3="Select Your Choice : "

f(){

	t=0
	for var in $@
	do
		t=`expr $var + $t`
	done
}

select menu in total used free quit
do
	case $menu in
	total) T=(`free -m | sed '1d' | awk '{print $2}'`)
		f ${T[@]}
		echo "Total memory: $t MB"
		;;

        
	used) U=(`free -m | sed '1d' | awk '{print $3}'`)
		f ${U[@]}
		echo "Total Used memory: $t MB"
		;;
    
        
	free) F=(`free -m | sed '1d' | awk '{print $4}'`)
		f ${F[@]}
		echo "Total Free memory: $t MB"
		;;

        
	quit) 
		echo "ThankYou !!"
                exit
		;;
	*) echo "Invalid Choice"
	   echo "Press Enter key"
     esac
done
