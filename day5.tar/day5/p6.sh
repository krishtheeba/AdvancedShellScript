
if [ $# -ne 1 ];then
	echo "Usage: Pass Inventory File"
	echo "$0 <inventoryfile>"
	exit
fi


awk 'BEGIN{

FS=":"

}

{
split($2,QTY,",")
total=0

for(x in QTY){
	total=total+QTY[x]
}

print "ItemCode: ", $1, "Total Sales Count : ", total

}
END{

print "----------------Thank You !!!! ------------------"
}' $1


