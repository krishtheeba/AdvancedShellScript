awk 'BEGIN{
print "Initialization of awk BEGIN block"}' emp.csv
