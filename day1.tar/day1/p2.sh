Fname="/etc/passwd"

echo "About $Fname details:-
-----------------------------"

ls -l $Fname

echo # Empty
<<Abc
hjhsjh
jshjs
Abc

echo "About $Fname Attributes are:
===================================="

stat $Fname

