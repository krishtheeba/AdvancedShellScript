read -p "Enter a shell name" sh_var

if [ "$sh_var" == "bash" ]
then
	read -p "Enter Application Name : " app
	read -p "Enter Port Number : " port
	
	web_App="$app:$port"
	echo "Web Url is : $web_App"
else
	echo "Sorry Your Shell name $sh_var is not bash "

fi
