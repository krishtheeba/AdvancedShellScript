read -p "Enter the port"  port

if [ $port -gt 500 ]
then
	echo "Valid- input port $port is above 500"
else
	echo "Invalid- input port $port is below 500"
fi

read -p "Enter a app name: " app

if [ "$app" == "Django" ]
then
	echo "Valid-App is Django"
else
	echo "Invalid  $app not matched"
fi


