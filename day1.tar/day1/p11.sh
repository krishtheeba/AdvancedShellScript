

read -p "Enter Linux Command :" cmd

$cmd > result.log 2>&1

if [ $? -eq 0 ];then
	echo "$cmd execution is Success"
else
	echo "$cmd execution Failed. Refer result.log"

fi
