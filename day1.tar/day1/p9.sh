


read -p "Enter the shell name: " sh_var

if [ "$sh_var"  == "bash" ]
then
	fname="/etc/bashrc"
elif [ "$sh_var" == "ksh" ]
then
	fname="/etc/kshrc"
elif [ "$sh_var" == "csh" ]
then
	fname="/etc/cshrc"
else
	sh_var="/etc/nologin"
	fname="/etc/profile"
fi

echo "Shell Name : $sh_var Profile filename : $fname"
