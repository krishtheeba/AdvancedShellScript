
os=`uname`
DATE=`date +%D`
Fname="/etc/passwd"
count=`lsmod|wc -l`


echo "Working Kernel name is : $os"
echo "File Name is : $Fname"
echo "Total no. of loaded kernel module: $count"
echo "Today : $DATE"
