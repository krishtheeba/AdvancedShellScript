read -p "Enter a filename" Fname

echo "About $Fname file details :-
=============================="

ls -l $Fname
