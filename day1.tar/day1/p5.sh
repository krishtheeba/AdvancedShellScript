
read -p "Enter a filename " f1
read -p "Enter $f1 size" s1

read -p "Enter a filename " f2
read -p "Enter $f2 size" s2

total=$((s1+s2))

echo -e "
Filename : $f1\t Size : $s1
Filename : $f2\t Size : $s2
==========================
Total File Size : $total
========================= "

