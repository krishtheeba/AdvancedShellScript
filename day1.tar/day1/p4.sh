read -p "Enter a Filename" fname
read -p "Enter a fileSize" fsize

filepath=`find -name $fname`
export fname

echo "File Name : $fname
File Path : $filepath
File Size : $fsize"


