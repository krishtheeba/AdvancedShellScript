

read -p "Enter the Shell name: " sh_var

if [ "$sh_var" == "bash" ]
then
	read -p "Enter the Application Name: " app
	if [ "$app" == "Flask" -o "$app" == "Django" ]
	then
		read -p "Enter the Port Number: " port
		if [ $port -gt 500 -a $port -lt 600 ]
		then
			web_app="$app:$port"
			echo "Web Url is : $web_app"
		else
			echo "Sorry $port is Not Valid"
		fi
	else
		echo "Sorry input Application $app Not Matched"
		fi
else
	echo "Sorry input Shell name is not bash"
fi
		
