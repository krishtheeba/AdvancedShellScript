echo "This is shell script PID:$$"
r=`mysql -u root -p ""<<EOF
  use demo1;
  drop table if exists product1;
  create table product1(pid INT,pname VARCHAR(20));
  insert into product1(pid,pname) values(101,'pA');
  insert into product1(pid,pname) values(102,'pB');
  insert into product1(pid,pname) values(103,'pC');
  select * from product1;
EOF`
################
#
# var=`command`
#
##############

if [ -z "$r" ]
then
	echo "Empty record"
else
	echo "$r"
fi
echo "$r" >db.log # create a newfile and write to logfile
###################

echo "Exit from shell script PID:$$"
