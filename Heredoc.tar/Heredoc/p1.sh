## Heredocument 

cat<<Abc
   <html>
   <head>
   <title>welcome</title>
   <body>
   <p>
   test message
   </p>
   </body>
   </head>
   </html>
Abc
