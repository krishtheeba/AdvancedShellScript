echo "This is shell script PID:$$"
mysql -u root -p ""<<EOF
  show databases;
  use demo1;
  drop table if exists product1;
  create table product1(pid INT,pname VARCHAR(20));
  insert into product1(pid,pname) values(101,'pA');
  insert into product1(pid,pname) values(102,'pB');
  insert into product1(pid,pname) values(103,'pC');
  select * from product1;
  delete from product1 where pid = 103;
EOF
echo "Exit from shell script PID:$$"
