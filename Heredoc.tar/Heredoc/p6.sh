echo "PID:$$"
echo "this is `hostname` system"
echo "working kernel is:`uname -rs`"
echo # empty line
r=`ssh krosumlabs<<EOF
 uname -a
 sleep 2
 uptime
 ps -f
EOF`
echo "$r"
echo # empty line
echo "this is `hostname` system"
echo "PID:$$"
