echo "PID:$$"
echo "this is `hostname` system"
echo "working kernel is:`uname -rs`"
echo # empty line
ssh krosumlabs<<EOF
 uname -a
 sleep 2
 uptime
EOF
echo # empty line
echo "this is `hostname` system"
echo "PID:$$"
